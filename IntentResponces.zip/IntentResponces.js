'use strict';

exports.IntentResponce = function () {

   var rad = 'Yeah, it was pretty rad';

};

